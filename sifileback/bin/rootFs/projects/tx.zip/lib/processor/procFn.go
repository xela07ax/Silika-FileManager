package processor


import (
	"fmt"
	"github.com/xela07ax/Silika-FileManager/sifileback/lib/dockerApi"
	"sync"
	"time"
)
type ToDocker struct {
	Data []byte
	Acton string // Приходит команда на распаковку и запуск
	ch chan ToDocker
}
const (
	fn = "Processor"
	limit = 15
)
type ProcessorCfg struct {
	PortsStart int // С какого порта начинаем выдачу под докер
	PortsEnd int // Это число минус верхнее, будет количество потоков
	Loger chan <-[4]string
	WorkDir string // С этой папки смотрим остальные пути и ее подключим докеру
	KodConfigZip string // zip файл, который распаковывается в рабочую папку докера
}
type Box struct {
	Tx chan ToDocker
	process *mutexRunner
	loger chan <-[4]string
	stopPrepare *mutexStopper
	stopX chan bool
	GoodBy chan bool
}

func NewProcessor(cfg ProcessorCfg) (Processor *Box, errTx string) {
	if cfg.Loger == nil {
		return nil, "логер не передан"
	}
	cfg.Loger  <- [4]string{fn,"nil","Модуль-балансировщик инициализация"}
	// Обработчик команд для поднятия докера, распаковка пакета и файлов настроек, завершение   докера и сохранение, п также удаление остатков
	cntMinions := cfg.PortsEnd - cfg.PortsStart

	if cntMinions > 15 || cntMinions < 1 {
		return nil, fmt.Sprintf("количество миньонов не может быть больше %d или меньше 1, проверьте диапаон портов",limit)
	}
	box :=  &Box {
		Tx:make(chan ToDocker),
		loger:cfg.Loger,
		stopPrepare:new(mutexStopper),
		process:new(mutexRunner),
		stopX:make(chan bool,1000),
		GoodBy:make(chan bool, 2), // todo:Про завершение надо еще подумать
	}
	for i := 0; i < cntMinions; i++ {
		// Запускаем миньонов
		go box.RunMinion(cfg.PortsStart-1+i)
	}
	return box, ""
}
type mutexStopper struct {
	mu sync.Mutex
	x  bool
}
func (c *mutexStopper) stopSignal()  {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.x = true
	return
}
func (p *Box) Stop()  {
	p.stopPrepare.stopSignal()
	for i:=0; i <  p.GetCores(); i++ {
		<-p.stopX
	}
	p.GoodBy <- true
	fmt.Println("Модуль-балансировщик завершил все миньоны")
	return
}
func (p *Box) SignalStoper(off <-chan bool)  {
	<- off
	p.Stop()
	fmt.Println("Модуль-балансировщик завершил все миньоны")
	p.GoodBy <- true
	return
}
type mutexRunner struct {
	mu sync.Mutex
	x  int
}
func (c *mutexRunner) addRun()(i int)  {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.x++
	i = c.x
	return
}
func (c *Box) GetCores()(cores int)  {
	c.process.mu.Lock()
	cores = c.process.x
	c.process.mu.Unlock()
	return
}
func (p *Box) RunMinion(port int)  {
	p.process.addRun()
	go p.minion(port)
	return
}
func (p *Box) minion(gophere int)  {
	fmt.Printf("Миньен %d инициализирован\n",gophere)
	/*
		Какой то код, который нужно выполнить до того как начнется сам процесс считывания данных со входящкго канала
	*/
	var counter int
	for  {
		select {
		case task := <-p.Tx:
			// Пришла команда
			task.ch <- ToDocker{
				Data:  nil,
				Acton: "Start",
				ch:    nil,
			}
			// Распакуем пришедший проект, развернем все
			//task.Data
			// И надо дождаться команды на остановку в task.ch
			p.loger <- [4]string{fn,fmt.Sprintf("%d",gophere),fmt.Sprintf("Пришла команда")}

			dockerApi.RunContainer(dockerApi.Kod{
				Image:      "xaljer/kodexplorer",
				DockerPort: 80,
				HostPort:   0,
				DockerDir:  "/var/www/html",
				HostDir:    "",
			})
			//newElement := fmt.Sprintf("%s - ок!", elem)

			if counter >= 50 {
				fmt.Printf("Мы достигли %d операций, все идет хорошо, продолжаю работу, я это миньен %d\n",counter,gophere)
				counter = 0
			}
			counter++
		default:
			if p.stopPrepare.x {
				fmt.Printf("Мы достигли %d операций, и я завершаю работу, я это миньен %d\n",counter,gophere)
				p.stopX <- true
				return
			}
			time.Sleep(1*time.Second)
		}
	}
}