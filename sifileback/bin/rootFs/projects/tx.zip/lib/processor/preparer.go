package processor

// Распакуем пришедший проект, развернем все

func ectractor(data []byte) {
}