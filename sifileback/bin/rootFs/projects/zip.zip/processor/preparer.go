package processor

import (
	"archive/zip"
	"fmt"
	"github.com/xela07ax/toolsXela/tp"
	"io"
	"os"
	"path/filepath"
	"strings"
)

// Распакуем пришедший проект, развернем все

func ectractor(data []byte)  {
	if tp.CheckMkdir(p.AbsoluteDestProject) != nil {
		return "Ошибка при создании темповой папки", err
		//return "Ошибка при поиске zip контейнера", err
	}
	_, err = Unzip(p.AbsoluteSrcProjectZip,p.AbsoluteDestProject)
	if err != nil {
		return "Ошибка при распаковке zip контейнера", err
	}
	return "", nil
}
