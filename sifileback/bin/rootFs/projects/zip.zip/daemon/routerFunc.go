package daemon

import (
	"fmt"
	"github.com/gorilla/websocket"
	"github.com/xela07ax/toolsXela/ttp"
	"log"
	"net/http"
)
var upgrader = websocket.Upgrader{} // use default options

var minions int
type Router struct {
	name string
	loger chan <- [4]string
}
func NewRouterManager(loger chan <- [4]string) *Router {
	return &Router{
		name: 		"RouteManager",
		loger: 		loger,
	}
}

const (
	daemon = "Daemon"
	conn = "Conn"
)


func (fs *Router) Conn(w http.ResponseWriter, r *http.Request)  {
	minions++
	unit := minions
	c, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		tx := fmt.Sprintf("upgrade: Не удалось создать соединение по WS|unit:%d | Ertx:%v",unit,err)
		ttp.Resp(w,r,conn, tx,1,true)
		fs.loger <- [4]string{daemon,conn,tx, "1"}
		return
	}
	defer c.Close()
	for {
		mt, message, err := c.ReadMessage()
		if err != nil {
			log.Println("read:", err)
			break
		}
		fmt.Printf("__Unit__:%d|recv: %s\n", unit, message)
		err = c.WriteMessage(mt, message)
		if err != nil {
			log.Println("write:", err)
			break
		}
	}
}